This app is designed for Hong Kong CityU student, especially for students from SEEM department. 
It provides general information for canteen in AC1 and SEEM department office. 
Currently, for AC1 canteen, the opening hour information is shown. 
Also, canteen��s location can be found through this app with direct connection to Google Map. 
For SEEM department office, the opening hour information, as well as the link directed to the department web page, are provided. 
In addition, there is a button for which user can direct dial to SEEM department.
In the future, AC2 canteen and AC3 canteen information will be added so as to improve the app.
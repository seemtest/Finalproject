package com.androidlin.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SEEM extends AppCompatActivity {

    private TextView mTextViewLink;
    private Button dialBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seem);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mTextViewLink = (TextView) findViewById(R.id.textViewLink);

        mTextViewLink.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String url = "http://www.cityu.edu.hk/seem/";
                Intent webintent = new Intent(Intent.ACTION_VIEW);
                webintent.setData(Uri.parse(url));
                startActivity(webintent);

            }
        });

        dialBtn = (Button) findViewById(R.id.buttonDial);
        dialBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri number = Uri.parse("tel:34429321");
                Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
                startActivity(callIntent);
            }
        });
    }

}
